#include"Calculadora.h"
#include"Calculadora_av.h"
#include<math.h>
bool impar(int num);
bool par(int num);
bool primo(int num);
