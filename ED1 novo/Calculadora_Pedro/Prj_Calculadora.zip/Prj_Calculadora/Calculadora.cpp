#include"Calculadora.h"
float soma(float n1, float n2)
{
	return n1+n2;
}
float sub(float n1, float n2)
{
return n1-n2;
}
float mult(float n1, float n2)
{
	return n1*n2;
}
float div(float n1, float n2)
{
	return n1/n2;
}
