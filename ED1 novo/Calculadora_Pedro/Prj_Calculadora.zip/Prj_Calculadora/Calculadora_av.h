#include<math.h>
float pot(float n1,float n2);
float raiz(float n1);
