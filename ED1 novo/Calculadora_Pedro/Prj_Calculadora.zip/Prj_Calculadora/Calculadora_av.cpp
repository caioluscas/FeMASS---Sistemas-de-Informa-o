#include"Calculadora.h"
float pot(float n1,float n2)
{
	return pow(n1,n2);
}
float raiz(float n1)
{
	return sqrt(n1);
}
