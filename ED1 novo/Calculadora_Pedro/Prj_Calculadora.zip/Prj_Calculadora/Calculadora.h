#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<iostream>
using namespace std;
float soma(float n1,float n2);
float sub(float n1,float n2);
float mult(float n1,float n2);
float div(float n1,float n2);
