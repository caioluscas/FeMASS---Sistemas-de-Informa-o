#include "cadastro.h"

cad* cadastro(cad * p, int ncad){
	fflush(stdin);
	if(ncad == 1){
		p = (cad*) malloc(ncad * sizeof(cad));
	}else if(ncad > 1){
		p = (cad*) realloc(p, ncad * sizeof(cad));
	}
	
	int x = ncad - 1;
	p[x].end = (char*) malloc (sizeof(char*));
	cout << "Nome: ";
	gets(p[x].end);
	fflush(stdin);
	
	p[x].nome = (char*) malloc (sizeof(char*));
	cout << "\nEndere�o: ";
	gets(p[x].nome);
	fflush(stdin);
	
	cout << "\nRG: ";
    scanf("%d",&p[x].rg);
    fflush(stdin);
    
    cout << "\nCPF: ";
    scanf("%d",&p[x].cpf);
    fflush(stdin);
    
    return p;
}



void Exibir( int ncad, cad* p){
    for (int i = 0; i < ncad; i++)
        cout <<"\nNome: "<<p[i].nome<<" Endere�o: "<<p[i].end<<" RG: "<<p[i].rg<<" CPF: "<<p[i].cpf;
}


void Quantidade (int qtd){
	printf("\nQuantidade de n�meros cadastrados: %d",qtd);
}

cad * removerult(cad * p, int *n){
	if(*n>0){
		p = (cad*) realloc (p, (*n - 1) * sizeof(cad));
		*n = *n - 1;
		cout << "Removido!";
	}
	else{
		cout << "Sem usu�rios para remover!";
	}
	return p;
}

/*cad* arquivo(cad* u, int *n, int a)
{
	for(int i=0; i<n; i++)
	{
		fscanf(a, "%s | %s | %s | %s", &u[i].nome, &u[i].rg &u[i].cpf, &u[i].endereco); 
	}
}*/
