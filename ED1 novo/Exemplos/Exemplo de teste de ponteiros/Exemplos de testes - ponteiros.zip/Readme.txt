Readme:

- "teste_ponteiros.cpp" - observar declara��o de ponteiros, acesso a endere�o de mem�ria e refer�ncia de ponteiro.

- "teste_ponteiros2_0.cpp" e "teste_ponteiros2_1.cpp" - diferen�a entre chamadas de fun��es sem (valor) e com (refer�ncia) o uso de ponteiros.

- "teste_ponteiros3.cpp" - Manipulando structs via ponteiros.